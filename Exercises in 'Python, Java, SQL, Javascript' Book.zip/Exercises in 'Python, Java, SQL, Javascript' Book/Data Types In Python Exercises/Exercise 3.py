dict = {'soccer': 'ball' , 'basket':'ball', 'foot' : 'hand' , 'tennis' : 'ball', 'golf' : 'ball'}

x = list(dict.values())[2]
print(x)


