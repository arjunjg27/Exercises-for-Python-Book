nums = [1,2,3,4,5]
numssum = sum(nums[0:5])
numavg = numssum / len(nums)
print(numssum)
print(numavg)