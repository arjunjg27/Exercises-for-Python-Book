t = ("John", "Bob", "Sam", "Aaron", " Joe")
fal = t[0] + t[-1]
print(fal)