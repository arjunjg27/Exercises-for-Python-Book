age = int(input("Age in Years:"))
sec = age *365*24*60*60
print(sec)