temp = int(input("Temperature in Fahrenheit:"))
cel = (temp - 32)* 5/9
cel = float(cel)
print(cel)