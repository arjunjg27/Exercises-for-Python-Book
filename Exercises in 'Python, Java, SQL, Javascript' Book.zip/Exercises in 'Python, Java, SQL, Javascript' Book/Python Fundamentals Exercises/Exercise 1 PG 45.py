a = int(input("Number 1:"))
b = int(input("Number 2:"))
add = a + b
sub = a - b
mult = a * b
div = a / b
print(add,"\n", sub,"\n", mult,"\n", div)