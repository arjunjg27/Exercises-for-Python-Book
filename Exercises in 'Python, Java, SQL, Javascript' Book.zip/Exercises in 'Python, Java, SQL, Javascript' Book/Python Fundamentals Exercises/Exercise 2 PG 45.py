a = int(input("Number 1:"))
b = int(input("Number 2:"))
mod = a % b
flo = a // b
print( mod, "\n", flo)